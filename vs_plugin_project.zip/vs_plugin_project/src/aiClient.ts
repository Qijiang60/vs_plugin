import OpenAI from "openai";
import { buildUnitTestPrompt } from "./promptBuilder";
import { SourceLanguage } from "./fileUtils";

export interface AiGenerateRequest {
    apiKey: string;
    model: string;
    framework: string;
    fileName: string;
    sourceLanguage: SourceLanguage;
    sourceCode: string;
    apiBaseUrl?: string;
}

export async function generateUnitTestsWithAI(request: AiGenerateRequest): Promise<string> {
    const client = new OpenAI({
        apiKey: request.apiKey,
        ...(request.apiBaseUrl && request.apiBaseUrl.trim().length > 0
            ? { baseURL: request.apiBaseUrl.trim() }
            : {})
    });

    const prompt = buildUnitTestPrompt({
        framework: request.framework,
        fileName: request.fileName,
        sourceLanguage: request.sourceLanguage,
        sourceCode: request.sourceCode
    });

    const response = await client.responses.create({
        model: request.model,
        input: prompt
    });

    const text = response.output_text;

    if (!text || text.trim().length === 0) {
        throw new Error("AI returned an empty response.");
    }

    return cleanupAiCode(text);
}

function cleanupAiCode(text: string): string {
    let cleaned = text.trim();

    cleaned = cleaned.replace(/^```[a-zA-Z0-9]*\s*/g, "");
    cleaned = cleaned.replace(/```$/g, "");

    return cleaned.trim() + "\n";
}
