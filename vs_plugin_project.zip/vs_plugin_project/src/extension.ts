import * as vscode from "vscode";
import * as path from "path";
import { generateUnitTestsWithAI } from "./aiClient";
import { detectSourceLanguage, isSupportedCOrCppFile } from "./fileUtils";
import { writeGeneratedTestFile } from "./testWriter";

const SECRET_KEY = "cppUnitTestAi.openaiApiKey";

export function activate(context: vscode.ExtensionContext) {
    const setApiKeyCommand = vscode.commands.registerCommand(
        "cppUnitTestAi.setApiKey",
        async () => {
            await setApiKey(context);
        }
    );

    const clearApiKeyCommand = vscode.commands.registerCommand(
        "cppUnitTestAi.clearApiKey",
        async () => {
            await context.secrets.delete(SECRET_KEY);
            vscode.window.showInformationMessage("API key cleared.");
        }
    );

    const generateTestsCommand = vscode.commands.registerCommand(
        "cppUnitTestAi.generateTests",
        async () => {
            try {
                await generateTests(context);
            } catch (error: unknown) {
                const message = error instanceof Error ? error.message : String(error);
                vscode.window.showErrorMessage(`Failed to generate tests: ${message}`);
            }
        }
    );

    context.subscriptions.push(setApiKeyCommand, clearApiKeyCommand, generateTestsCommand);
}

export function deactivate() {}

async function setApiKey(context: vscode.ExtensionContext): Promise<void> {
    const apiKey = await vscode.window.showInputBox({
        prompt: "Enter your OpenAI API key",
        password: true,
        ignoreFocusOut: true
    });

    if (!apiKey || apiKey.trim().length === 0) {
        vscode.window.showWarningMessage("API key was not saved.");
        return;
    }

    await context.secrets.store(SECRET_KEY, apiKey.trim());
    vscode.window.showInformationMessage("API key saved securely.");
}

async function generateTests(context: vscode.ExtensionContext): Promise<void> {
    const editor = vscode.window.activeTextEditor;

    if (!editor) {
        vscode.window.showErrorMessage("No active editor found.");
        return;
    }

    const document = editor.document;
    const fileName = document.fileName;

    if (!isSupportedCOrCppFile(fileName)) {
        vscode.window.showErrorMessage("Please open a C/C++ source or header file.");
        return;
    }

    let apiKey = await context.secrets.get(SECRET_KEY);

    if (!apiKey) {
        const answer = await vscode.window.showErrorMessage(
            "API key is missing. Please set it first.",
            "Set API Key"
        );

        if (answer === "Set API Key") {
            await setApiKey(context);
            apiKey = await context.secrets.get(SECRET_KEY);
        }

        if (!apiKey) {
            return;
        }
    }

    const selectedText = document.getText(editor.selection);
    const sourceCode = selectedText.trim().length > 0 ? selectedText : document.getText();

    if (!sourceCode.trim()) {
        vscode.window.showErrorMessage("No source code found.");
        return;
    }

    const config = vscode.workspace.getConfiguration("cppUnitTestAi");
    const model = config.get<string>("model", "gpt-5.1");
    const framework = config.get<string>("framework", "gtest");
    const testFolder = config.get<string>("testFolder", "tests");
    const overwriteExistingFile = config.get<boolean>("overwriteExistingFile", false);
    const apiBaseUrl = config.get<string>("apiBaseUrl", "");
    const sourceLanguage = detectSourceLanguage(fileName);

    await vscode.window.withProgress(
        {
            location: vscode.ProgressLocation.Notification,
            title: "Generating C/C++ unit tests with AI...",
            cancellable: false
        },
        async () => {
            const generatedCode = await generateUnitTestsWithAI({
                apiKey,
                model,
                framework,
                fileName: path.basename(fileName),
                sourceLanguage,
                sourceCode,
                apiBaseUrl
            });

            await writeGeneratedTestFile({
                sourceDocument: document,
                generatedCode,
                framework,
                testFolder,
                overwriteExistingFile
            });
        }
    );
}
