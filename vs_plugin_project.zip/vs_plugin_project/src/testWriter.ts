import * as vscode from "vscode";
import { buildTestFileName } from "./fileUtils";

export interface WriteTestFileRequest {
    sourceDocument: vscode.TextDocument;
    generatedCode: string;
    framework: string;
    testFolder: string;
    overwriteExistingFile: boolean;
}

export async function writeGeneratedTestFile(request: WriteTestFileRequest): Promise<void> {
    const workspaceFolder = vscode.workspace.getWorkspaceFolder(request.sourceDocument.uri);
    const sourceFile = request.sourceDocument.fileName;
    const testFileName = buildTestFileName(sourceFile, request.framework);

    if (!workspaceFolder) {
        const newDoc = await vscode.workspace.openTextDocument({
            content: request.generatedCode,
            language: request.framework === "unity" ? "c" : "cpp"
        });

        await vscode.window.showTextDocument(newDoc);
        return;
    }

    const outputDir = vscode.Uri.joinPath(workspaceFolder.uri, request.testFolder);
    const outputFile = vscode.Uri.joinPath(outputDir, testFileName);

    if (!request.overwriteExistingFile) {
        const exists = await fileExists(outputFile);

        if (exists) {
            const answer = await vscode.window.showWarningMessage(
                `${testFileName} already exists. Overwrite it?`,
                "Overwrite",
                "Open Existing",
                "Cancel"
            );

            if (answer === "Open Existing") {
                const doc = await vscode.workspace.openTextDocument(outputFile);
                await vscode.window.showTextDocument(doc);
                return;
            }

            if (answer !== "Overwrite") {
                return;
            }
        }
    }

    await vscode.workspace.fs.createDirectory(outputDir);
    await vscode.workspace.fs.writeFile(outputFile, Buffer.from(request.generatedCode, "utf8"));

    const newDoc = await vscode.workspace.openTextDocument(outputFile);
    await vscode.window.showTextDocument(newDoc);

    vscode.window.showInformationMessage(`Generated ${testFileName}`);
}

async function fileExists(uri: vscode.Uri): Promise<boolean> {
    try {
        await vscode.workspace.fs.stat(uri);
        return true;
    } catch {
        return false;
    }
}
