import { SourceLanguage } from "./fileUtils";

export interface UnitTestPromptRequest {
    framework: string;
    fileName: string;
    sourceLanguage: SourceLanguage;
    sourceCode: string;
}

export function buildUnitTestPrompt(request: UnitTestPromptRequest): string {
    return `
You are a senior C/C++ unit test engineer.

Generate unit tests for the provided ${request.sourceLanguage} code.

Return rules:
- Return only source code.
- Do not include markdown.
- Do not include explanation.
- Do not wrap the answer in triple backticks.

Framework:
- Use this framework: ${request.framework}

General requirements:
- Generate complete compilable unit test code.
- Include required headers.
- Use meaningful test names.
- Include normal test cases.
- Include edge cases.
- Include boundary cases.
- Include negative/error cases where possible.
- If expected value is unknown, add TODO comments.
- If external dependency exists, add TODO comments for mock/stub.
- If function has pointer arguments, create safe dummy values.
- If function has array arguments, create small test arrays.
- If function has struct arguments, create initialized struct values.
- If function has global state, include setup/teardown TODO comments.

C/C++ specific rules:
- Source file name: ${request.fileName}
- Source language: ${request.sourceLanguage}
- If source language is C and framework is gtest, create a .cpp test file and wrap C headers with extern "C".
- If source language is C++ and class methods exist, use TEST_F when setup is useful.
- If source language is C, do not invent C++ production APIs.
- If framework is unity, generate C test code using TEST_ASSERT_* macros.
- If framework is cpputest, generate TEST_GROUP and TEST cases.

Important:
- Do not change the production code.
- Do not assume private/static functions are directly accessible unless they are visible in the provided code.
- Prefer testing public functions declared in headers.
- Add TODO comments when mocks are required.

Input code:
${request.sourceCode}
`;
}
