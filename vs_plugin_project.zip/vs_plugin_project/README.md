# C/C++ Unit Test AI Generator VS Code Plugin

This VS Code extension generates C/C++ unit test cases using AI.

It can generate tests from:

- Selected C/C++ code
- The full active `.c`, `.cpp`, `.h`, `.hpp`, `.cc`, `.cxx`, or `.hxx` file

It supports these frameworks:

- GoogleTest / gtest
- Unity
- CppUTest

For a mixed C/C++ project, start with `gtest` because it can test C++ code directly and can test C code from a `.cpp` test file using `extern "C"`.

---

## 1. Project Structure

```text
cpp-unit-test-ai-generator/
├── package.json
├── tsconfig.json
├── src/
│   ├── extension.ts
│   ├── aiClient.ts
│   ├── promptBuilder.ts
│   ├── testWriter.ts
│   └── fileUtils.ts
└── README.md
```

---

## 2. Prerequisites

Install Node.js and npm first.

Then install VS Code extension tools:

```bash
npm install -g yo generator-code vsce
```

Install project dependencies:

```bash
npm install
```

---

## 3. Build the Extension

Compile TypeScript:

```bash
npm run compile
```

Watch mode during development:

```bash
npm run watch
```

---

## 4. Run the Extension Locally

Open this project folder in VS Code.

Press:

```text
F5
```

A new VS Code window opens called **Extension Development Host**.

In that new window:

1. Open a C/C++ project.
2. Open a `.c`, `.cpp`, `.h`, or `.hpp` file.
3. Run Command Palette:

```text
Ctrl + Shift + P
```

4. Run:

```text
C/C++ Unit Test AI: Set API Key
```

5. Paste your OpenAI API key.
6. Run:

```text
C/C++ Unit Test AI: Generate Tests
```

The generated test file will be created under:

```text
tests/
```

Example output:

```text
tests/calculator_test.cpp
```

---

## 5. Commands

This extension contributes three commands:

```text
C/C++ Unit Test AI: Set API Key
C/C++ Unit Test AI: Generate Tests
C/C++ Unit Test AI: Clear API Key
```

You can run them from:

```text
Ctrl + Shift + P
```

You can also right-click inside a supported C/C++ file and run:

```text
C/C++ Unit Test AI: Generate Tests
```

---

## 6. Settings

Open VS Code settings JSON and configure:

```json
{
  "cppUnitTestAi.model": "gpt-5.1",
  "cppUnitTestAi.framework": "gtest",
  "cppUnitTestAi.testFolder": "tests",
  "cppUnitTestAi.overwriteExistingFile": false,
  "cppUnitTestAi.apiBaseUrl": ""
}
```

### Setting Details

| Setting | Description |
|---|---|
| `cppUnitTestAi.model` | AI model name. |
| `cppUnitTestAi.framework` | Test framework: `gtest`, `unity`, or `cpputest`. |
| `cppUnitTestAi.testFolder` | Folder where generated test files are saved. |
| `cppUnitTestAi.overwriteExistingFile` | If `true`, overwrite an existing test file. |
| `cppUnitTestAi.apiBaseUrl` | Optional OpenAI-compatible endpoint. Leave empty for default OpenAI endpoint. |

---

## 7. API Key Storage

The API key is not stored in `settings.json`.

It is stored using VS Code `SecretStorage`.

To save the key:

```text
C/C++ Unit Test AI: Set API Key
```

To remove the key:

```text
C/C++ Unit Test AI: Clear API Key
```

---

## 8. Example: C++ Input

Open a file named `calculator.cpp`:

```cpp
#include "calculator.h"

int add(int a, int b) {
    return a + b;
}

bool isPositive(int value) {
    return value > 0;
}
```

Run:

```text
C/C++ Unit Test AI: Generate Tests
```

Expected generated output example:

```cpp
#include <gtest/gtest.h>
#include "calculator.h"

TEST(CalculatorTest, AddPositiveNumbers) {
    EXPECT_EQ(5, add(2, 3));
}

TEST(CalculatorTest, AddNegativeNumbers) {
    EXPECT_EQ(-5, add(-2, -3));
}

TEST(CalculatorTest, AddWithZero) {
    EXPECT_EQ(3, add(0, 3));
}

TEST(CalculatorTest, IsPositiveReturnsTrueForPositiveNumber) {
    EXPECT_TRUE(isPositive(10));
}

TEST(CalculatorTest, IsPositiveReturnsFalseForZero) {
    EXPECT_FALSE(isPositive(0));
}

TEST(CalculatorTest, IsPositiveReturnsFalseForNegativeNumber) {
    EXPECT_FALSE(isPositive(-1));
}
```

---

## 9. Example: C Input with GoogleTest

Open a file named `math_utils.c`:

```c
#include "math_utils.h"

int add(int a, int b) {
    return a + b;
}
```

Generated GoogleTest output should look like:

```cpp
#include <gtest/gtest.h>

extern "C" {
#include "math_utils.h"
}

TEST(MathUtilsTest, AddPositiveNumbers) {
    EXPECT_EQ(5, add(2, 3));
}

TEST(MathUtilsTest, AddNegativeNumbers) {
    EXPECT_EQ(-5, add(-2, -3));
}

TEST(MathUtilsTest, AddWithZero) {
    EXPECT_EQ(3, add(0, 3));
}
```

The `extern "C"` block is important when testing C code from a C++ GoogleTest file.

---

## 10. Package the Extension

Build a `.vsix` package:

```bash
npm run package
```

This creates a file like:

```text
cpp-unit-test-ai-generator-0.0.1.vsix
```

Install it locally:

```bash
code --install-extension cpp-unit-test-ai-generator-0.0.1.vsix
```

---

## 11. Push This Project to GitHub

Your repo:

```text
https://github.com/Qijiang60/vs_plugin.git
```

From the project root, run:

```bash
git init
git branch -M main
git add .
git commit -m "Add C/C++ unit test AI VS Code extension"
git remote add origin https://github.com/Qijiang60/vs_plugin.git
git push -u origin main
```

If the repo already has files, use this safer flow:

```bash
git clone https://github.com/Qijiang60/vs_plugin.git
cd vs_plugin

# Copy these generated project files into this folder.

npm install
npm run compile

git add .
git commit -m "Add C/C++ unit test AI VS Code extension"
git push
```

If Git asks for login, use a GitHub Personal Access Token instead of your password.

---

## 12. How the Extension Works

### `extension.ts`

Registers commands:

- Set API key
- Clear API key
- Generate tests

It reads the selected code or full file, detects whether the file is C or C++, and calls the AI client.

### `aiClient.ts`

Calls the OpenAI-compatible API and returns generated test code.

### `promptBuilder.ts`

Builds the AI prompt. This controls the quality of generated tests.

### `testWriter.ts`

Writes the AI-generated test code into the configured `tests/` folder.

### `fileUtils.ts`

Detects supported file types and chooses output test file names.

---

## 13. Current MVP Limitations

This MVP sends selected code or the full active file directly to AI.

It does not yet:

- Parse the full project include graph
- Automatically update `CMakeLists.txt`
- Automatically build/run tests
- Automatically generate mocks from headers
- Detect all private/static functions correctly
- Guarantee generated tests compile without project-specific include/link settings

---

## 14. Recommended Next Improvements

Good next steps:

1. Add command: `Generate Test for Selected Function Only`
2. Add command: `Generate CMake Test Target`
3. Add support for local/internal AI endpoint
4. Add support for Unity + CMock mock generation
5. Add option to append tests to existing test file
6. Add test execution command
7. Add project context collection from nearby header files

---

## 15. Company Code Warning

If this extension is used on company source code, confirm that your company allows sending source code to the configured AI API.

For internal or restricted code, use one of these options:

- Company-approved OpenAI account
- Azure OpenAI
- Internal AI endpoint
- Local LLM endpoint

The `cppUnitTestAi.apiBaseUrl` setting exists so you can later point this extension to an internal OpenAI-compatible API.
