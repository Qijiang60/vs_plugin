import * as vscode from "vscode";
import * as path from "path";
import { detectSourceLanguage, isSupportedCOrCppFile } from "./fileUtils";
import { generateWithInternalCompanyAI } from "./internalAiClient";
import { generateLocalGoogleTestSkeleton } from "./localSkeletonGenerator";
import { writeGeneratedTestFile } from "./testWriter";

const SECRET_KEY = "cppUnitTest.internalApiKey";
type GenerationMode = "local" | "internal";

export function activate(context: vscode.ExtensionContext) {
    context.subscriptions.push(
        vscode.commands.registerCommand("cppUnitTest.setInternalApiKey", async () => setInternalApiKey(context)),
        vscode.commands.registerCommand("cppUnitTest.clearInternalApiKey", async () => clearInternalApiKey(context)),
        vscode.commands.registerCommand("cppUnitTest.generateTests", async () => generateTests(context)),
        vscode.commands.registerCommand("cppUnitTest.generateInternalAiTests", async () => generateTests(context, "internal")),
        vscode.commands.registerCommand("cppUnitTest.generateLocalSkeleton", async () => generateTests(context, "local"))
    );
}

export function deactivate() {}

async function setInternalApiKey(context: vscode.ExtensionContext): Promise<void> {
    const apiKey = await vscode.window.showInputBox({
        prompt: "Enter your internal company AI API key. Leave blank if your internal API does not require one.",
        password: true,
        ignoreFocusOut: true
    });

    if (!apiKey || apiKey.trim().length === 0) {
        vscode.window.showWarningMessage("Internal AI API key was not saved.");
        return;
    }

    await context.secrets.store(SECRET_KEY, apiKey.trim());
    vscode.window.showInformationMessage("Internal AI API key saved securely.");
}

async function clearInternalApiKey(context: vscode.ExtensionContext): Promise<void> {
    await context.secrets.delete(SECRET_KEY);
    vscode.window.showInformationMessage("Internal AI API key cleared.");
}

async function generateTests(context: vscode.ExtensionContext, forcedMode?: GenerationMode): Promise<void> {
    try {
        const editor = vscode.window.activeTextEditor;

        if (!editor) {
            vscode.window.showErrorMessage("No active editor found.");
            return;
        }

        const document = editor.document;
        const fileName = document.fileName;

        if (!isSupportedCOrCppFile(fileName)) {
            vscode.window.showErrorMessage("Please open a C/C++ source or header file.");
            return;
        }

        const selectedText = document.getText(editor.selection);
        const sourceCode = selectedText.trim().length > 0 ? selectedText : document.getText();

        if (!sourceCode.trim()) {
            vscode.window.showErrorMessage("No source code found.");
            return;
        }

        const config = vscode.workspace.getConfiguration("cppUnitTest");
        const generationMode = forcedMode ?? config.get<GenerationMode>("generationMode", "local");
        const internalApiBaseUrl = config.get<string>("internalApiBaseUrl", "https://your-company-ai-server.example.com");
        const internalModel = config.get<string>("internalModel", "company-coder-model");
        const testFolder = config.get<string>("testFolder", "tests");
        const overwriteExistingFile = config.get<boolean>("overwriteExistingFile", false);
        const sourceLanguage = detectSourceLanguage(fileName);

        await vscode.window.withProgress(
            {
                location: vscode.ProgressLocation.Notification,
                title: generationMode === "internal"
                    ? "Generating GoogleTest with internal company AI..."
                    : "Generating local GoogleTest skeleton...",
                cancellable: false
            },
            async () => {
                let generatedCode: string;

                if (generationMode === "internal") {
                    const apiKey = await context.secrets.get(SECRET_KEY);

                    generatedCode = await generateWithInternalCompanyAI({
                        apiBaseUrl: internalApiBaseUrl,
                        apiKey,
                        model: internalModel,
                        fileName: path.basename(fileName),
                        sourceLanguage,
                        sourceCode
                    });
                } else {
                    generatedCode = generateLocalGoogleTestSkeleton({
                        fileName: path.basename(fileName),
                        sourceLanguage,
                        sourceCode
                    });
                }

                await writeGeneratedTestFile({
                    sourceDocument: document,
                    generatedCode,
                    testFolder,
                    overwriteExistingFile
                });
            }
        );
    } catch (error: any) {
        vscode.window.showErrorMessage(`Failed to generate tests: ${error.message}`);
    }
}
