import * as path from "path";

export type SourceLanguage = "C" | "C++";

export function isSupportedCOrCppFile(fileName: string): boolean {
    const ext = path.extname(fileName).toLowerCase();
    return [".c", ".h", ".cpp", ".cc", ".cxx", ".hpp", ".hxx"].includes(ext);
}

export function detectSourceLanguage(fileName: string): SourceLanguage {
    const ext = path.extname(fileName).toLowerCase();
    if (ext === ".c" || ext === ".h") {
        return "C";
    }
    return "C++";
}

export function buildTestFileName(sourceFileName: string): string {
    const ext = path.extname(sourceFileName);
    const baseName = path.basename(sourceFileName, ext);
    return `${baseName}_test.cpp`;
}
