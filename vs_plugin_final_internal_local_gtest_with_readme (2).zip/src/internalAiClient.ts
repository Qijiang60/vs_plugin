import { buildUnitTestPrompt } from "./promptBuilder";
import { SourceLanguage } from "./fileUtils";

export interface InternalAiGenerateRequest {
    apiBaseUrl: string;
    apiKey?: string;
    model: string;
    fileName: string;
    sourceLanguage: SourceLanguage;
    sourceCode: string;
}

export async function generateWithInternalCompanyAI(
    request: InternalAiGenerateRequest
): Promise<string> {
    const prompt = buildUnitTestPrompt({
        fileName: request.fileName,
        sourceLanguage: request.sourceLanguage,
        sourceCode: request.sourceCode
    });

    const url = `${request.apiBaseUrl.replace(/\/$/, "")}/generate-unit-tests`;

    const headers: Record<string, string> = {
        "Content-Type": "application/json"
    };

    if (request.apiKey) {
        headers["Authorization"] = `Bearer ${request.apiKey}`;
    }

    const response = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify({
            model: request.model,
            framework: "gtest",
            fileName: request.fileName,
            language: request.sourceLanguage,
            sourceCode: request.sourceCode,
            prompt
        })
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Internal AI request failed. HTTP ${response.status}: ${errorText}`);
    }

    const data = await response.json() as {
        code?: string;
        text?: string;
        result?: string;
        error?: string;
    };

    if (data.error) {
        throw new Error(`Internal AI error: ${data.error}`);
    }

    const generatedCode = data.code || data.text || data.result;

    if (!generatedCode || generatedCode.trim().length === 0) {
        throw new Error("Internal AI returned empty generated code.");
    }

    return cleanupAiCode(generatedCode);
}

function cleanupAiCode(text: string): string {
    let cleaned = text.trim();
    cleaned = cleaned.replace(/^```[a-zA-Z0-9]*\s*/g, "");
    cleaned = cleaned.replace(/```$/g, "");
    return cleaned.trim() + "\n";
}
