import * as path from "path";
import { SourceLanguage } from "./fileUtils";

export interface LocalGenerateRequest {
    fileName: string;
    sourceLanguage: SourceLanguage;
    sourceCode: string;
}

interface FunctionInfo {
    returnType: string;
    name: string;
    args: string;
}

export function generateLocalGoogleTestSkeleton(request: LocalGenerateRequest): string {
    const functions = extractFunctions(request.sourceCode);
    const headerName = guessHeaderName(request.fileName);
    const suiteName = toPascalCase(path.basename(request.fileName, path.extname(request.fileName))) + "Test";

    const includeBlock = request.sourceLanguage === "C"
        ? `#include <gtest/gtest.h>

extern "C" {
#include "${headerName}"
}`
        : `#include <gtest/gtest.h>
#include "${headerName}"`;

    if (functions.length === 0) {
        return `${includeBlock}

TEST(${suiteName}, TodoShouldWork) {
    // TODO: add test case
}
`;
    }

    const testBlocks = functions.map(fn => {
        const testName = `${toPascalCase(fn.name)}ShouldWork`;
        const callArgs = buildDefaultCallArgs(fn.args);

        if (fn.returnType === "void") {
            return `TEST(${suiteName}, ${testName}) {
    // TODO: arrange

    ${fn.name}(${callArgs});

    // TODO: assert side effects
}`;
        }

        return `TEST(${suiteName}, ${testName}) {
    // TODO: arrange

    auto result = ${fn.name}(${callArgs});

    // TODO: assert
    // EXPECT_EQ(expected, result);
}`;
    }).join("\n\n");

    return `${includeBlock}

${testBlocks}
`;
}

function extractFunctions(sourceCode: string): FunctionInfo[] {
    const cleaned = sourceCode
        .replace(/\/\*[\s\S]*?\*\//g, "")
        .replace(/\/\/.*$/gm, "");

    const functions: FunctionInfo[] = [];
    const regex = /(?:^|\n)\s*([A-Za-z_][\w\s\*\:&<>,~]*?)\s+([A-Za-z_]\w*)\s*\(([^;{}()]*)\)\s*(?:;|\{)/g;

    let match: RegExpExecArray | null;
    while ((match = regex.exec(cleaned)) !== null) {
        const returnType = match[1].trim();
        const name = match[2].trim();
        const args = match[3].trim();

        if (!shouldSkip(name, returnType)) {
            functions.push({ returnType, name, args });
        }
    }

    return functions;
}

function shouldSkip(name: string, returnType: string): boolean {
    const skipNames = ["if", "for", "while", "switch", "catch", "return", "sizeof"];
    return skipNames.includes(name) || returnType.includes("=");
}

function guessHeaderName(fileName: string): string {
    const ext = path.extname(fileName);
    const base = path.basename(fileName, ext);

    if ([".c", ".cpp", ".cc", ".cxx"].includes(ext)) {
        return `${base}.h`;
    }

    return path.basename(fileName);
}

function buildDefaultCallArgs(args: string): string {
    if (!args || args.trim() === "void") {
        return "";
    }

    return args.split(",").map(arg => defaultValueForArg(arg.trim())).join(", ");
}

function defaultValueForArg(arg: string): string {
    const lower = arg.toLowerCase();

    if (lower.includes("*")) {
        return "nullptr";
    }

    if (lower.includes("bool")) {
        return "false";
    }

    if (lower.includes("char")) {
        return "'a'";
    }

    if (lower.includes("float") || lower.includes("double")) {
        return "0.0";
    }

    if (lower.includes("int") || lower.includes("short") || lower.includes("long") || lower.includes("size_t")) {
        return "0";
    }

    return "{}";
}

function toPascalCase(input: string): string {
    return input
        .replace(/[_\-]+/g, " ")
        .replace(/\w+/g, word => word.charAt(0).toUpperCase() + word.slice(1))
        .replace(/\s+/g, "");
}
