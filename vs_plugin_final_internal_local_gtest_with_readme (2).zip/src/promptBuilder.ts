import { SourceLanguage } from "./fileUtils";

export interface UnitTestPromptRequest {
    fileName: string;
    sourceLanguage: SourceLanguage;
    sourceCode: string;
}

export function buildUnitTestPrompt(request: UnitTestPromptRequest): string {
    return `
You are a senior C/C++ unit test engineer.

Generate GoogleTest unit tests for the provided ${request.sourceLanguage} code.

Return rules:
- Return only source code.
- Do not include markdown.
- Do not include explanation.
- Do not wrap the answer in triple backticks.

GoogleTest requirements:
- Use #include <gtest/gtest.h>.
- Generate complete compilable GoogleTest code.
- Use meaningful TEST or TEST_F names.
- Include normal, edge, boundary, and negative/error test cases when possible.
- If expected values are unknown, add TODO comments.
- If external dependencies exist, add TODO comments for mocks/stubs.
- If function has pointer arguments, create safe dummy values.
- If function has array arguments, create small test arrays.
- If function has struct arguments, create initialized struct values.
- If global state exists, add setup/teardown TODO comments.

C/C++ rules:
- Source file name: ${request.fileName}
- Source language: ${request.sourceLanguage}
- If source language is C, create a .cpp GoogleTest file and wrap C headers with extern "C".
- If source language is C++ and class methods exist, use TEST_F when setup is useful.
- Do not change production code.
- Prefer testing public functions declared in headers.
- Do not invent APIs that are not present in the provided code.

Input code:
${request.sourceCode}
`;
}
